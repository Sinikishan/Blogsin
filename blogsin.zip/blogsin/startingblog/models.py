from django.db import models
from django.contrib.auth.models import User
from django.urls import reverse

# Create your models here.
class Post(models.Model):
    title=models.CharField(max_length=255)
    header_image= models.ImageField(null=True,blank=True, upload_to ="images/")
    #title_tag=models.CharField(max_length=255, default ="Welcome to Blogsinzzz")
    title_tag=models.CharField(max_length=255)
    author=models.ForeignKey(User,on_delete =models.CASCADE)
    body=models.TextField()

    def __str__(self):
        return self.title + '|'+ str(self.author) 
    
    def get_absolute_url(self):
        #return reverse('article-detail', args = [str(self.id)]) 
        return reverse('home')

        
# Please note, article-detail passed as argument in reverse is the name value given in urls.py
#This is where the page need to redirect after clicking the post button,
#self.id is the kind of the primary key created for each field.

#if you get a pillow error , pip install Pillow or python -m pip install Pillow
