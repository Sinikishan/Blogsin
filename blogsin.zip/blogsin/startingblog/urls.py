
from django.urls import path
#We need to use the import views for Part 1
#from . import views

#for the part2 of the lab, please use the following import
# we are using class based views!
from .views import HomeView 
#HomeView is the name given by you in Views.py

from .views import ArticleDetailView,AddPostView
from django.conf import settings
from django.conf.urls.static import static

#ArticleDetailView is the name given in views.py for detailView

#from .views import 
#import for the AddPostView

urlpatterns = [
    #path('',views.home,name="Home" ),
    path('',HomeView.as_view(), name = "home"),
    #as_view is used as we are using class based views
    path('article/<int:pk>',ArticleDetailView.as_view(), name = "article-detail"),
    # 'article here tells you the way you need to call them
    #say http:..... /article  in that manner
    #<int:pk> is the unique primary key that is provided by the database
    # hence the first blog post will be article/1
    #article/2 etc.
    # then we call ArticleDetailView.as_view(), name = "article-detail"
    # as we have done for the ListView itself with a name.
    path('add_post/',AddPostView.as_view(), name = "add_post"),
    #Path for AddPostView
]
urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
# Now go to the home.html
# make the data from article-detail linkable by using href

