from django.shortcuts import render
#for the lab 8 part 2 use the 2 import statements below,
from django.views.generic import ListView,DetailView,CreateView
from .models import Post
from .forms import PostForm


# Create your views here.
#for the initial lab 8 part 1 use this 
#def home( request):
    #return render(request, 'home.html',{})

#for the lab 8 part 2 use this,
class HomeView(ListView):
    model = Post
    #Go to models.py and use the name of the model you created here.
    #I have created the model as Post, hence using that here.
    template_name = 'home.html'

# Now head to home.html and make changes 
# for working on Part 2 :-)

# Now for the second section  of Part 2 id to 
# demonstrate about DetailView!
# for that we are creating a class as given below:

class ArticleDetailView(DetailView):
    model = Post
    #Go to models.py and use the name of the model you created here.
    #I have created the model as Post, hence using that here.
    template_name = 'article_details.html'
    #this name is the name created in the templates folder
    # for the details view

#We need to import ArticleDetailView in urls.py
# now lets head to article_details.html and populate them in the way we need!


class AddPostView(CreateView):
    model = Post
    #Go to models.py and use the name of the model you created here.
    #I have created the model as Post, hence using that here.
    form_class =PostForm
    template_name = 'add_post.html'
    #this name is the name created in the templates folder
    # for the createView
    #CreateView helps create new things , say in this case new Posts!
    #fields = '__all__'
    #fields = '__all__'  this will put all the fields in the AddPost Page!
    #fields = ('title','body')
    #In the fields , we can specify the needed fields from models.py as a python list
    #then in the add post page we will have only title and body!




